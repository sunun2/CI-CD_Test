package com.example.CICDTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CicdTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
